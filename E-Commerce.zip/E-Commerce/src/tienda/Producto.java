
package tienda;

import decorador.Decorador;

/**
 *
 * @author jjkoo
 */
public class Producto implements Decorador {
    
    private String id;
    private double precio;
    private String nombre;
    private int cantidadStock;
    private String descripcion;
    private String categoria;

    public Producto(String id, double precio, String nombre, int cantidadStock, String descripcion, String categoria) {
        this.id = id;
        this.precio = precio;
        this.nombre = nombre;
        this.cantidadStock = cantidadStock;
        this.descripcion = descripcion;
        this.categoria = categoria;
    }
    
    public int actualizarStock(int cantidad, int forma){
        if(forma == 2){
            cantidadStock = cantidadStock + cantidad;
        }
        else if(forma == 1){
            cantidadStock = cantidadStock - cantidad;
        }
        return cantidadStock;
    }
    
    
    public String getDetalles (){
        return "El producto "+nombre+": "+descripcion+", "+categoria; 
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @return the precio
     */
    @Override
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the cantidadStock
     */
    public int getCantidadStock() {
        return cantidadStock;
    }

    /**
     * @return the descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * @param descripcion the descripcion to set
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * @return the categoria
     */
    public String getCategoria() {
        return categoria;
    }

    /**
     * @param categoria the categoria to set
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", precio=" + precio + ", nombre=" + nombre + ", cantidadStock=" + cantidadStock + ", descripcion=" + descripcion + ", categoria=" + categoria + '}';
    } 
}
