
package tienda;

import java.util.ArrayList;
import java.util.List;
import proxy.*;

/**
 *
 * @author jjkoo
 */
public class Sistema implements ISistema {
    
    private static Sistema instancia;
    private List<Usuario> usuarios;
    private List<Producto> inventario;
    private Usuario usuarioActual;

    private Sistema() {
        usuarios = new ArrayList<>();
        inventario = new ArrayList<>();
    }
    
    public static Sistema getInstancia(){
        if (instancia == null){
            instancia = new Sistema();
        }
        return instancia;
    }
    
    public Producto getProducto(String nombre) {
        for (Producto producto : this.inventario) { // Asumiendo que 'productos' es un arreglo o una lista
            if (producto.getNombre().equals(nombre)) {
                return producto;
            }
        }
        return null; // Si no se encuentra el producto, se retorna null
    }
    
    @Override
    public void agregarProducto(String id, double precio, String nombre, int cantidadStock, String descripcion, String categoria){
        inventario.add(new Producto(id,precio,nombre,cantidadStock,descripcion,categoria));
    }
    
    public void agregarProducto(Producto p){
        inventario.add(p);
    }
    
    @Override
    public void registrarUsuario(String id, String nombre, String correo, String contraseña){
        usuarios.add(new Usuario(id,nombre,correo,contraseña));
    }
    
    @Override
    public void actualizarInventario(String id, int cantidad){
        for (int i = 0; i < inventario.size(); i++) {
            if(inventario.get(i).getId() .equals(id)){
                inventario.get(i).actualizarStock(cantidad,1);
            }
        }
    }
    
    @Override
    public String buscarProducto(String nombre, String categoria, int forma){
        if(forma == 1){
            for (int i = 0; i < inventario.size(); i++) {
            Producto p = inventario.get(i);
            if (p.getCategoria().equals(categoria) && p.getNombre().equals(nombre)) {
                return p.getDetalles();
            }
        }
        }
        else if(forma == 2){
           return usuarioActual.buscarProducto(nombre, categoria);
        }
        return "No se encuentra";
    }
    
    public boolean verificarSesion(){
        return usuarioActual != null;
    }
    
    @Override
    public String mostrarCarro(){
        return usuarioActual.getCarrito().mostrarProductos();
    }
    
    @Override
    public String mostrarInventario(){
        String salida = "";
        for (Producto c : inventario) {
            salida += c + "\n";
        }
        return salida;
    }
    
    @Override
    public boolean iniciarSesion(String correo, String contraseña){
        if (usuarioActual == null){
            for (int i = 0; i < usuarios.size(); i++) {
                if(usuarios.get(i).getCorreo() .equals(correo) && usuarios.get(i).getContraseña() .equals(contraseña)){
                    usuarioActual = usuarios.get(i);
                    return true;
                }
            }        
        }
        return false;
    }
    
    @Override
    public boolean cerrarSesion(){
        if(usuarioActual != null){
            usuarioActual = null;
            return true;
        } else return false;      
    }
    
    @Override
    public void actualizarDireccion (String direccion){
        usuarioActual.actualizarDireccion(direccion);
    }
    
    @Override
    public void cambiarContraseña(String contraseña){
        usuarioActual.setContraseña(contraseña);
    }
    
    @Override
    public boolean agregarAlCarrito(String nombre, int cantidad){
        return usuarioActual.agregarAlCarrito(nombre, cantidad, instancia);
    }
    
    @Override
    public boolean retirarDelCarrito(String nombre, int cantidad){
        return usuarioActual.retirarDelCarrito(nombre, cantidad, instancia);
    }
    
    @Override
    public String realizarCompra(){
        return usuarioActual.realizarCompra();
    }
    
    @Override
    public void vaciarCarrito(){
        usuarioActual.vaciarCarrito();
    }
    
    @Override
    public void elegirMetodoPago(String metodo){
        usuarioActual.elegirMetodoPago(metodo);
    }  
}
