
package observador;

/**
 *
 * @author jjkoo
 */
public interface IObserver {
    
    public void update();
}
