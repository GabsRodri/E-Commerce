
package observador;

/**
 *
 * @author jjkoo
 */
public class Observador implements IObserver {
    
    private String id;
    
    public Observador(String id){
        this.id = id;
    }
    
    @Override
    public void update(){
        System.out.println("Se han actualizado los productos.");
    }
}
