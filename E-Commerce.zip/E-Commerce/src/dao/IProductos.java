
package dao;

import java.util.List;
import tienda.Producto;

/**
 *
 * @author jjkoo
 */
public interface IProductos {

    public List<Producto> getAllProductos();
    public void addProducto(Producto producto);
    public void updateProducto(Producto producto);
    public Producto searchProducto(Producto producto);
    public void deleteProducto(Producto producto);
}
