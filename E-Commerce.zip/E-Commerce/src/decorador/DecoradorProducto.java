
package decorador;

import tienda.Producto;

/**
 *
 * @author jjkoo
 */
abstract class DecoradorProducto implements Decorador {
    protected Producto productoDecorado;

    public DecoradorProducto(Producto productoDecorado) {
        this.productoDecorado = productoDecorado;
    }

    @Override
    public abstract double getPrecio();
}
