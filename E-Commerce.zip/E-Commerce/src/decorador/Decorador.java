
package decorador;

/**
 *
 * @author jjkoo
 */
public interface Decorador {
    public double getPrecio();
}