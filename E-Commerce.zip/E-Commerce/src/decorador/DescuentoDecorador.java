
package decorador;

import tienda.Producto;

/**
 *
 * @author jjkoo
 */
public class DescuentoDecorador extends DecoradorProducto{
    private double porcentajeDescuento;

    public DescuentoDecorador(Producto productoDecorado, double porcentajeDescuento) {
        super(productoDecorado);
        this.porcentajeDescuento = porcentajeDescuento;
    }
     
    private double aplicarDescuento() {
        double precioConDescuento = productoDecorado.getPrecio() * (1 - porcentajeDescuento / 100);
        return precioConDescuento;
    }

    @Override
    public double getPrecio() {
        return aplicarDescuento();
    }
}
