package dao;

import java.util.List;
import tienda.Producto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jjkoo
 */
public class ProductoDAO implements IProductos {

    private String driver;
    private String url;
    private String login;
    private String password;
    private String sentencia;
    private Connection connection;
    private Statement statement;
    private ResultSet rs;
    private Producto producto;

    public ProductoDAO() {
        this.driver = "org.apache.derby.jdbc.ClientDriver";
        this.url = "jdbc:derby//localhost1527/sample";
        this.login = "app";
        this.password = "app";
        this.sentencia = "";
        this.connection = null;
        this.statement = null;
        this.rs = null;
    }

    public void conectar() {
        try {
            Class.forName(driver);
            System.out.println("...cargar los controladores para el acceso.");
            connection = DriverManager.getConnection(url, login, password);
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
    
    public void desconectar(Connection con){
        try{
            con.close();
        } catch(SQLException ex){
            System.out.println("Error: "+ex.getMessage());
        }
    }

    @Override
    public List<Producto> getAllProductos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void addProducto(Producto producto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void updateProducto(Producto producto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Producto searchProducto(Producto producto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteProducto(Producto producto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
