
package decorador;

import tienda.Producto;

/**
 *
 * @author jjkoo
 */
public class DescuentoDecorador extends DecoradorProducto{
    private double porcentajeDescuento;

    public DescuentoDecorador(Producto productoDecorado, double porcentajeDescuento) {
        super(productoDecorado);
        this.porcentajeDescuento = porcentajeDescuento;
    }
     
    @Override
    public void aplicarDescuento() {
        double precioConDescuento = productoDecorado.getPrecio() * porcentajeDescuento;
        productoDecorado.setPrecio(precioConDescuento);
    }

}
