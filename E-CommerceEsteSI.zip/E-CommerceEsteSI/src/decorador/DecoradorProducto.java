
package decorador;

import tienda.Producto;

/**
 *
 * @author jjkoo
 */
abstract class DecoradorProducto extends Producto{
    protected Producto productoDecorado;

    public DecoradorProducto(Producto productoDecorado) {
        super(productoDecorado.getId(), productoDecorado.getPrecio(), productoDecorado.getNombre(),
              productoDecorado.getCantidadStock(), productoDecorado.getDescripcion(), productoDecorado.getCategoria());
        this.productoDecorado = productoDecorado;
    }


    public abstract void aplicarDescuento();
}
