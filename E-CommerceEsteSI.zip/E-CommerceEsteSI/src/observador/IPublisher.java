
package observador;

/**
 *
 * @author jjkoo
 */
public interface IPublisher {
    
    public void agregarObservador(Observador ob);
    public void eliminarObservador(Observador ob);
    public void notificarObservadores();
}
