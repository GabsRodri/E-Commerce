
package proxy;

/**
 *
 * @author jjkoo
 */
public interface ISistema {
   
    public void agregarProducto(String id, double precio, String nombre, int cantidadStock, String descripcion, String categoria);
    public void registrarUsuario(String id, String nombre, String correo, String contraseña);
    public void actualizarInventario(String id, int cantidad);
    public boolean iniciarSesion(String correo, String contraseña);
    public boolean cerrarSesion();
    public void actualizarDireccion(String direccion);
    public void cambiarContraseña(String contraseña);
    public boolean agregarAlCarrito(String nombre, int cantidad);
    public boolean retirarDelCarrito(String nombre, int cantidad);
    public String realizarCompra();
    public void vaciarCarrito();
    public void elegirMetodoPago(String metodo);
    public String buscarProducto(String nombre, String categoria, int forma);
    public String mostrarCarro();
    public String mostrarInventario();
}
