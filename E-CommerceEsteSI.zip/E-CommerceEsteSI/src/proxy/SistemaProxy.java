package proxy;

import java.util.*;
import observador.*;
import tienda.Producto;
import tienda.Sistema;

/**
 *
 * @author jjkoo
 */
public class SistemaProxy implements IPublisher, ISistema {
    
    private static Sistema sistema;
    private List<Observador> observadores;
    
    public SistemaProxy() {
        sistema = Sistema.getInstancia();
        observadores = new ArrayList<>();
    }
    
    @Override
    public void agregarObservador(Observador observador) {
        observadores.add(observador);
    }

    /**
     * Elimina un observador de la lista de observadores.
     *
     * @param observador El observador a eliminar.
     */
    @Override
    public void eliminarObservador(Observador observador) {
        observadores.remove(observador);
    }

    /**
     * Notifica a todos los observadores cuando se actualiza el sistema.
     */
    @Override
    public void notificarObservadores() {
        for (Observador observador : observadores) {
            observador.update();
        }
    }
    
    @Override
    public String mostrarCarro(){
        return sistema.mostrarCarro();
    }
    
    @Override
    public String mostrarInventario(){
        return sistema.mostrarInventario();
    }
    
    @Override
    public void agregarProducto(String id, double precio, String nombre, int cantidadStock, String descripcion, String categoria) {
        notificarObservadores();
        if (precio != 0) {
            sistema.agregarProducto(id, precio, nombre, cantidadStock, descripcion, categoria);
        }
    }
    
    public void agregarProducto(Producto p){
        sistema.agregarProducto(p);
    }
    
    @Override
    public void registrarUsuario(String id, String nombre, String correo, String contraseña) {
        if (!(contraseña.equals("")) && !(correo.equals(""))) {
            sistema.registrarUsuario(id, nombre, correo, contraseña);
        }
    }
    
    @Override
    public void actualizarInventario(String id, int cantidad) {
        notificarObservadores();
        if (!(id.equals(""))) {
            sistema.actualizarInventario(id, cantidad);
        }
    }
    
    @Override
    public boolean iniciarSesion(String correo, String contraseña) {
        if (!(contraseña.equals("")) && !(correo.equals(""))) {
            return sistema.iniciarSesion(correo, contraseña);
        }
        return false;
    }
    
    @Override
    public boolean cerrarSesion() {
        if (sistema.verificarSesion()) {
            return sistema.cerrarSesion();
        }
        return false;
    }
    
    @Override
    public void actualizarDireccion(String direccion) {
        if (sistema.verificarSesion()) {
            sistema.actualizarDireccion(direccion);
        }
    }
    
    @Override
    public void cambiarContraseña(String contraseña) {
        if (!(contraseña.equals(""))) {
            sistema.cambiarContraseña(contraseña);
        }
    }
    
    @Override
    public boolean agregarAlCarrito(String nombre, int cantidad) {
        notificarObservadores();
        if (sistema.verificarSesion()) {
            return sistema.agregarAlCarrito(nombre, cantidad);
        }
        return false;
    }
    
    @Override
    public boolean retirarDelCarrito(String nombre, int cantidad) {
        notificarObservadores();
        if (sistema.verificarSesion()) {
            return sistema.retirarDelCarrito(nombre, cantidad);
        }
        return false;
    }
    
    @Override
    public String realizarCompra() {
        if (sistema.verificarSesion()) {
            return sistema.realizarCompra();
        }
        return "No ha iniciado sesion.";
    }
    
    @Override
    public void vaciarCarrito() {
        if (sistema.verificarSesion()) {
            sistema.vaciarCarrito();
        }
    }
    
    @Override
    public void elegirMetodoPago(String metodo) {
        if (sistema.verificarSesion()) {
            sistema.elegirMetodoPago(metodo);
        }
    }
    
    @Override
    public String buscarProducto(String nombre, String categoria, int forma) {
        if(sistema.verificarSesion()){
            return sistema.buscarProducto(nombre, categoria, forma);
        }
        return "No ha iniciado sesion.";
    }
}
