package tienda;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jjkoo
 */
public class Carrito {

    private List<Producto> productos;
    private double precioTotal;

    public Carrito() {
        productos = new ArrayList<>();
        precioTotal = 0;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public void retirarProducto(Producto producto) {
        productos.remove(producto);
    }

    public void vaciarCarrito() {
        productos.clear();
    }

    public void calcularTotal() {
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            precioTotal += p.getPrecio();
        }
    }

    public Producto buscarProducto(String nombre, String categoria) {
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            if (p.getCategoria().equals(categoria) && p.getNombre().equals(nombre)) {
                return p;
            }
        }
        return null;
    }

    public Producto getProducto(String nombre) {
        for (Producto producto : productos) { // Asumiendo que 'productos' es un arreglo o una lista
            if (producto.getNombre().equals(nombre)) {
                return producto;
            }
        }
        return null; // Si no se encuentra el producto, se retorna null
    }
    
    public Producto getProducto(int index){
        return productos.get(index);
    }

    @Override
    public String toString() {
        return "Carrito{" + "productos=" + productos + ", precioTotal=" + getPrecioTotal() + '}';
    }

    /**
     * @return the precioTotal
     */
    public double getPrecioTotal() {
        return precioTotal;
    }
    
    public int getCantidadProductos(){
        return productos.size();
    }
    
    public String mostrarProductos(){
        String salida = "";
        for (Producto c : productos) {
            salida += c + "\n";
        }
        return salida;      
    }
}
