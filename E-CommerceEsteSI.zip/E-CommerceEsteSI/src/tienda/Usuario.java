package tienda;

import java.time.LocalDateTime;

/**
 *
 * @author jjkoo
 */
public class Usuario {

    private String id;
    private String nombre;
    private String correo;
    private String contraseña;
    private Carrito carrito;
    private String direccion;
    private String metodo;

    public Usuario(String id, String nombre, String correo, String contraseña) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.contraseña = contraseña;
        this.carrito = new Carrito();
    }

    public void actualizarDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean cambiarContraseña(String contraseña) {
        if (!(this.contraseña.equals(contraseña))) {
            this.contraseña = contraseña;
            return true;
        }
        return false;
    }

    public boolean agregarAlCarrito(String nombre, int cantidad, Sistema s) {
        Producto p = s.getProducto(nombre);
        p.actualizarStock(cantidad, 1);
        carrito.agregarProducto(p);
        return true;
    }

    public boolean retirarDelCarrito(String nombre, int cantidad, Sistema s) {
        Producto p = getCarrito().getProducto(nombre);
        if (p != null) {
            p.actualizarStock(cantidad, 2);
            getCarrito().retirarProducto(p);
            return true;
        } else {
            return false;
        }
    }

    public String realizarCompra() {
        String recibo;
        if (getMetodo() != null) {
            carrito.calcularTotal();
            double precio = carrito.getPrecioTotal();
            recibo = """
                                    VIRTUTIENDA                                
                                    --------------------------------
                                    --------------------------------
                                    SU COMPRA FUE:
                         
                                    """ + carrito.mostrarProductos()
                    + """
                          ------------------------------------------
                          ------------------------------------------
                          EL TOTAL DE LA COMPRA FUE:                         
                          """ + precio + """

                          PAGO REALIZADO POR:
                          """ + getMetodo() + """
                          """;
            return recibo;
        }
        return "No hay metodo de pago elegido.";
    }

    public void vaciarCarrito() {
        getCarrito().vaciarCarrito();
    }

    public void elegirMetodoPago(String metodo) {
        this.metodo = metodo;
    }

    public String buscarProducto(String nombre, String categoria) {
        Producto p = getCarrito().buscarProducto(nombre, categoria);
        return p.getDetalles();
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @return the carrito
     */
    public Carrito getCarrito() {
        return carrito;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @return the metodo
     */
    public String getMetodo() {
        return metodo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    @Override
    public String toString() {
        return "Usuario{" + "id=" + id + ", nombre=" + nombre + ", correo=" + correo + ", direccion=" + direccion + ", metodo=" + metodo + '}';
    }
}
