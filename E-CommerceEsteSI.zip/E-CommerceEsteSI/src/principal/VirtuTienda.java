package principal;

import decorador.DescuentoDecorador;
import java.util.Scanner;
import observador.Observador;
import proxy.SistemaProxy;
import tienda.Producto;

/**
 *
 * @author jjkoo
 */
public class VirtuTienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int opcion, cantidad, metodo;
        String correo, contraseña, id, nombre, direccion, categoria;
        boolean loop = false, loop2 = true;

        SistemaProxy sis = new SistemaProxy();
        sis.agregarProducto("1", 20.0, "papa", 30, "papas para comer", "comida");
        sis.agregarProducto("3", 10.0, "tablet", 30, "tablet lenovo", "tecnologia");
        sis.agregarProducto("4", 15.0, "tenedor", 30, "tenedor de plata", "hogar");
        sis.agregarProducto("5", 60.0, "taza", 30, "taza de porcelana", "hogar");
        sis.agregarProducto("6", 70.0, "pantalon", 30, "pantalon de mezclilla", "ropa");

        sis.actualizarInventario("2", 200);

        Producto p = new Producto("7", 20.0, "coca", 2, "coca para comer", "comida");
        DescuentoDecorador e = new DescuentoDecorador(p, 0.7); 
        e.aplicarDescuento();
        sis.agregarProducto(e);

        while (loop2) {
            System.out.println("""
                           BIENVENIDO.
                           ---------------------
                           Elija una opcion:
                           1. Iniciar Sesion.
                           2. Registrarse.
                           """);
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el correo: ");
                    correo = sc.next();
                    System.out.println("Ingrese la contrasena: ");
                    contraseña = sc.next();
                    if (sis.iniciarSesion(correo, contraseña)) {
                        System.out.println("Se inicio correctamente.");
                        loop = true;
                        loop2 = false;
                    } else {
                        System.out.println("No se pudo iniciar sesion.");
                    }
                    break;
                case 2:
                    System.out.println("Ingrese su id: ");
                    id = sc.next();
                    System.out.println("Ingrese su nombre: ");
                    nombre = sc.next();
                    System.out.println("Ingrese el correo: ");
                    correo = sc.next();
                    System.out.println("Ingrese la contrasena: ");
                    contraseña = sc.next();
                    sis.registrarUsuario(id, nombre, correo, contraseña);
                    sis.agregarObservador(new Observador(id));
                    break;
                default:
                    System.out.println("Elija una opcion valida.");
                    break;
            }

            while (loop) {
                System.out.println("""
                               Elija una opcion:
                               1. Actualizar direccion.
                               2. Agregar al carrito.
                               3. Retirar del carrito.
                               4. Realizar Compra.
                               5. Vaciar Carrito.
                               6. Elejir metodo de pago.
                               7. Buscar producto.
                               8. Ver todos los productos disponibles.
                               9. Ver todos los productos en el carrito.
                               10. Cerrar sesion.
                               11. Cambiar contrasena.
                               """);
                opcion = sc.nextInt();
                switch (opcion) {
                    case 1:
                        System.out.println("Ingrese una la direccion: ");
                        direccion = sc.next();
                        sis.actualizarDireccion(direccion);
                        break;
                    case 2:
                        System.out.println("Escriba el nombre del producto: ");
                        nombre = sc.next();
                        System.out.println("Ingrese la cantidad: ");
                        cantidad = sc.nextInt();
                        if (sis.agregarAlCarrito(nombre, cantidad)) {
                            System.out.println("Se agrego correctamente.");
                        } else {
                            System.out.println("No se pudo agregar.");
                        }
                        break;
                    case 3:
                        System.out.println("Escriba el nombre del producto: ");
                        nombre = sc.next();
                        System.out.println("Ingrese la cantidad: ");
                        cantidad = sc.nextInt();
                        if (sis.retirarDelCarrito(nombre, cantidad)) {
                            System.out.println("Se retiro correctamente.");
                        } else {
                            System.out.println("No se pudo retirar.");
                        }
                        break;
                    case 4:
                        if (!(sis.realizarCompra().equals(""))) {
                            System.out.println(sis.realizarCompra());
                        } else {
                            System.out.println("No se puede realizar la compra.");
                        }
                        sis.vaciarCarrito();
                        break;
                    case 5:
                        sis.vaciarCarrito();
                        break;
                    case 6:
                        System.out.println("Elija un metodo de pago: \n1. Tarjeta. \n2. PSE. \n3. Contraentrega.");
                        metodo = sc.nextInt();
                        switch (metodo) {
                            case 1:
                                sis.elegirMetodoPago("tarjeta");
                                break;
                            case 2:
                                sis.elegirMetodoPago("pse");
                                break;
                            case 3:
                                sis.elegirMetodoPago("contraentrega");
                                break;
                            default:
                                System.out.println("Elija una opcion valida.");
                        }
                        break;
                    case 7:
                        System.out.println("Ingrese el nombre del producto: ");
                        nombre = sc.next();
                        System.out.println("Ingrese la categoria del producto: ");
                        categoria = sc.next();
                        System.out.println(sis.buscarProducto(nombre, categoria, 1));
                        break;
                    case 8:
                        System.out.println("Los productos disponibles son: \n" + sis.mostrarInventario());
                        break;
                    case 9:
                        System.out.println("Los productos disponibles son: \n" + sis.mostrarCarro());
                        break;
                    case 10:
                        if (sis.cerrarSesion()) {
                            loop = false;
                            loop2 = true;
                        }
                        break;
                    case 11:
                        System.out.println("Ingrese la nueva contrasena: ");
                        contraseña = sc.next();
                        sis.cambiarContraseña(contraseña);
                        break;
                    default:
                        System.out.println("Elija una opcion valida.");
                        break;
                }
            }
        }
    }
}
